#!/bin/bash

$protoc30 --go_out=. ./models/iclick_adx_rtb_v3.proto
