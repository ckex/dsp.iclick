#!/bin/bash

nohup ./dsp.iclick > ./stdout.log 2>&1 &